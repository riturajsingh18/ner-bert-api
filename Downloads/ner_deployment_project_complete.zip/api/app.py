
from fastapi import FastAPI, Request
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForTokenClassification
from transformers import pipeline
import torch
import pickle

app = FastAPI()

# Load tokenizer and model
tokenizer = AutoTokenizer.from_pretrained("model/")
model = AutoModelForTokenClassification.from_pretrained("model/")

# Load labels (optional, in case needed elsewhere)
with open("model/labels.pkl", "rb") as f:
    labels = pickle.load(f)

# Create pipeline
ner_pipeline = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")

class InputText(BaseModel):
    text: str

@app.post("/predict")
def predict_entities(input_data: InputText):
    text = input_data.text
    predictions = ner_pipeline(text)
    return {"entities": predictions}
