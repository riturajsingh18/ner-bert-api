
from locust import HttpUser, task, between

class NERUser(HttpUser):
    wait_time = between(1, 3)

    @task
    def predict(self):
        payload = {
            "text": "Barack Obama was born in Hawaii and served as US President."
        }
        self.client.post("/predict", json=payload)
