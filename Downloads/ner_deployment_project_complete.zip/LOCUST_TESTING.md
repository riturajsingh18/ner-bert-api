
# 🧪 Load Testing with Locust

## Requirements
Install Locust:
```
pip install locust
```

## Run Test:
```
locust -f locustfile.py --host=http://localhost:8000
```

Then open browser at:
http://localhost:8089

- Set number of users and spawn rate.
- Start the test to simulate NER predictions.
