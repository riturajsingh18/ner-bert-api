
from transformers import AutoTokenizer, AutoModelForTokenClassification
import torch
import pickle

# Define the model and tokenizer
model_name = "dslim/bert-base-NER"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Save tokenizer and model
tokenizer.save_pretrained("model/")
model.save_pretrained("model/")

# Sample class labels for NER
labels = ['O', 'B-PER', 'I-PER', 'B-ORG', 'I-ORG', 'B-LOC', 'I-LOC', 'B-MISC', 'I-MISC']
with open("model/labels.pkl", "wb") as f:
    pickle.dump(labels, f)

print("Model and tokenizer saved successfully.")
