
# Grafana Monitoring Setup

1. Start Prometheus using the provided `prometheus.yml`.
2. Launch Grafana and add Prometheus as a data source.
3. Create dashboards for FastAPI metrics (e.g., request duration, success rate).
4. Use `prometheus_fastapi_instrumentator` in your FastAPI app to expose metrics.

# Additional Code for FastAPI Instrumentation

Add this to `app.py`:
```
from prometheus_fastapi_instrumentator import Instrumentator

instrumentator = Instrumentator().instrument(app).expose(app)
```
