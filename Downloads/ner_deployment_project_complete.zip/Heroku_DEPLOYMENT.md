
# 🚀 Heroku Deployment Guide

## Prerequisites
- Install Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli
- Create a Heroku account and login

## Steps
1. Create app:
   heroku create ner-bert-api

2. Add Heroku remote if not added:
   heroku git:remote -a ner-bert-api

3. Deploy:
   git add .
   git commit -m "Deploy to Heroku"
   git push heroku main

4. Open app:
   heroku open

NOTE:
- `Procfile` tells Heroku to run FastAPI using uvicorn
- `runtime.txt` sets Python version
- All dependencies are in `api/requirements.txt`
